import mongoose from "mongoose";
import { unique } from "next/dist/build/utils";

const userSchema = new mongoose.Schema({
    email: { 
        type: String, 
        required: true, 
        unique: true 
    },
    username:{
        type: String,
        required: true,
        unique: true,
    },
    password: { 
        type: String, 
        required: true 
    },
    role: {
        type: String,
        enum: ['admin', 'hr', 'employee'],
        default: 'employee',
    },
    employeeId: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'Employee' 
    }, // optional, if user is also an employee
}, { timestamps: true });

const User = mongoose.models.User || mongoose.model('User', userSchema)
export default User;
// module.exports = mongoose.models.User || mongoose.model('User', userSchema);
